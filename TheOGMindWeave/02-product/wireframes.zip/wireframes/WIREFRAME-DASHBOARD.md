# Wireframe: Main Dashboard

> The command center for enterprise AI governance

---

## Screen Overview

| Attribute | Value |
|-----------|-------|
| Screen ID | DASH-001 |
| Priority | P0 (MVP) |
| User Flow | Primary landing after login |
| Mobile Support | Responsive (limited) |

---

## Full Dashboard Layout

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│ ┌─────────────────────────────────────────────────────────────────────────────────────┐ │
│ │ ◈ MINDWEAVE        Dashboard   MCPs   Teams   Audit   Settings       🔔  👤 Susan ▼│ │
│ └─────────────────────────────────────────────────────────────────────────────────────┘ │
├───────────────┬─────────────────────────────────────────────────────────────────────────┤
│               │                                                                         │
│  NAVIGATION   │  Dashboard                                            Last 30 days ▼   │
│               │  ═══════════════════════════════════════════════════════════════════   │
│  ┌─────────┐  │                                                                         │
│  │📊 Dash  │  │  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐          │
│  └─────────┘  │  │ TOTAL TOKENS    │ │ TOTAL COST      │ │ ACTIVE MCPs     │          │
│  ┌─────────┐  │  │                 │ │                 │ │                 │          │
│  │🔌 MCPs  │  │  │   847.2M        │ │   $42,350       │ │   147           │          │
│  └─────────┘  │  │   ↑ 23% vs last │ │   ↑ 18% vs last │ │   ↑ 12 new      │          │
│  ┌─────────┐  │  │                 │ │                 │ │                 │          │
│  │👥 Teams │  │  └─────────────────┘ └─────────────────┘ └─────────────────┘          │
│  └─────────┘  │                                                                         │
│  ┌─────────┐  │  ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐          │
│  │📋 Audit │  │  │ ACTIVE USERS    │ │ CONVERSATIONS   │ │ AVG SESSION     │          │
│  └─────────┘  │  │                 │ │                 │ │                 │          │
│  ┌─────────┐  │  │   234           │ │   12,847        │ │   18 min        │          │
│  │⚙️ Config│  │  │   ↑ 8% vs last  │ │   ↑ 31% vs last │ │   ↓ 2 min       │          │
│  └─────────┘  │  │                 │ │                 │ │                 │          │
│               │  └─────────────────┘ └─────────────────┘ └─────────────────┘          │
│  ───────────  │                                                                         │
│               │  ═══════════════════════════════════════════════════════════════════   │
│  QUICK LINKS  │                                                                         │
│               │  Token Usage Over Time                                                  │
│  + Add MCP    │  ┌─────────────────────────────────────────────────────────────────┐   │
│  + Invite     │  │                                                                 │   │
│  + New Team   │  │         ╭──────────────────────────────────╮                   │   │
│               │  │      ╭──╯                                  ╰──╮                │   │
│  ───────────  │  │   ╭──╯                                        ╰──────────╮     │   │
│               │  │ ╭─╯                                                       ╰─╮  │   │
│  RESOURCES    │  │─╯                                                           ╰─│   │
│               │  │ Dec 1    Dec 8     Dec 15    Dec 22    Dec 29               │   │
│  📖 Docs      │  │                                                                 │   │
│  💬 Support   │  │ ● Engineering  ● Product  ● Sales  ● Marketing                 │   │
│  🎓 Training  │  └─────────────────────────────────────────────────────────────────┘   │
│               │                                                                         │
│               │  ═══════════════════════════════════════════════════════════════════   │
│               │                                                                         │
│               │  ┌──────────────────────────────────┐ ┌──────────────────────────────┐ │
│               │  │ TOP TEAMS BY USAGE               │ │ RECENT ACTIVITY              │ │
│               │  ├──────────────────────────────────┤ ├──────────────────────────────┤ │
│               │  │                                  │ │                              │ │
│               │  │ 1. Engineering      523M (62%)  │ │ 🔔 Susan created new MCP     │ │
│               │  │    ████████████████████░░░░░░   │ │    "Jira Ticket Reader"      │ │
│               │  │                                  │ │    2 minutes ago             │ │
│               │  │ 2. Product          187M (22%)  │ │                              │ │
│               │  │    ███████░░░░░░░░░░░░░░░░░░░   │ │ 🔔 David hit 80% of budget   │ │
│               │  │                                  │ │    Backend Team              │ │
│               │  │ 3. Sales            94M (11%)   │ │    15 minutes ago            │ │
│               │  │    ███░░░░░░░░░░░░░░░░░░░░░░░   │ │                              │ │
│               │  │                                  │ │ 🔔 New MCP shared: GitHub    │ │
│               │  │ 4. Marketing        43M (5%)    │ │    PR Analyzer               │ │
│               │  │    █░░░░░░░░░░░░░░░░░░░░░░░░░   │ │    1 hour ago                │ │
│               │  │                                  │ │                              │ │
│               │  │ View all teams →                 │ │ View all activity →          │ │
│               │  └──────────────────────────────────┘ └──────────────────────────────┘ │
│               │                                                                         │
└───────────────┴─────────────────────────────────────────────────────────────────────────┘
```

---

## Metric Cards (KPI Section)

### Card Layout Detail

```
┌────────────────────────────────────────┐
│  TOTAL TOKENS                          │
│                                        │
│  ┌────┐                                │
│  │ 📊 │   847.2M                       │
│  └────┘                                │
│                                        │
│  ↑ 23%  vs last 30 days                │
│  ────────────────────────────          │
│  ████████████████░░░░░░░░  78% of cap  │
│                                        │
└────────────────────────────────────────┘
```

### Metric Card States

**Normal State:**
```
┌────────────────────────┐
│  ACTIVE USERS          │
│  234                   │
│  ↑ 8% vs last          │
│  (green arrow)         │
└────────────────────────┘
```

**Warning State (>80% budget):**
```
┌────────────────────────┐
│  TOTAL COST     ⚠️    │
│  $42,350               │
│  82% of monthly budget │
│  (orange border)       │
└────────────────────────┘
```

**Critical State (>95% budget):**
```
┌────────────────────────┐
│  TOTAL COST     🔴    │
│  $48,500               │
│  97% - Approaching cap │
│  (red border, pulse)   │
└────────────────────────┘
```

---

## Sidebar Navigation

```
┌─────────────────┐
│                 │
│  ◈ MINDWEAVE    │
│                 │
├─────────────────┤
│                 │
│  📊 Dashboard   │  ← Active (blue bg)
│                 │
│  🔌 MCPs        │
│     All MCPs    │
│     My MCPs     │
│     Shared      │
│                 │
│  👥 Teams       │
│     All Teams   │
│     My Team     │
│                 │
│  📋 Audit       │
│     Logs        │
│     Reports     │
│                 │
│  ⚙️ Settings    │
│                 │
├─────────────────┤
│                 │
│  QUICK ACTIONS  │
│  ┌───────────┐  │
│  │ + Add MCP │  │
│  └───────────┘  │
│  ┌───────────┐  │
│  │ + Invite  │  │
│  └───────────┘  │
│                 │
├─────────────────┤
│                 │
│  📖 Docs        │
│  💬 Support     │
│  🎓 Training    │
│                 │
├─────────────────┤
│                 │
│  ▼ Susan Chen   │
│    @susan.chen  │
│    Eng Manager  │
│                 │
└─────────────────┘
```

---

## Top Navigation Bar

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                                                                                         │
│  ◈ MINDWEAVE    Dashboard   MCPs   Teams   Audit   Settings         🔍   🔔 3   👤 ▼  │
│                    ↑                                                     │    │    │    │
│                 Active                                               Search Bell User  │
│                 (underline)                                                             │
│                                                                                         │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### Notification Bell Dropdown

```
                                              ┌────────────────────────────┐
                                              │ Notifications         ✓ ✓ │
                                              ├────────────────────────────┤
                                              │ 🔔 Susan created MCP       │
                                              │    "Jira Ticket Reader"    │
                                              │    2 min ago               │
                                              ├────────────────────────────┤
                                              │ ⚠️ Budget alert           │
                                              │    Backend Team at 80%     │
                                              │    15 min ago              │
                                              ├────────────────────────────┤
                                              │ 🔌 New shared MCP          │
                                              │    GitHub PR Analyzer      │
                                              │    1 hour ago              │
                                              ├────────────────────────────┤
                                              │ View all notifications →   │
                                              └────────────────────────────┘
```

### User Dropdown

```
                                                          ┌────────────────────┐
                                                          │ 👤 Susan Chen      │
                                                          │    Eng Manager     │
                                                          │    Engineering     │
                                                          ├────────────────────┤
                                                          │ 👤 My Profile      │
                                                          │ ⚙️ Preferences     │
                                                          │ 🔑 API Keys        │
                                                          ├────────────────────┤
                                                          │ 📖 Documentation   │
                                                          │ 💬 Support         │
                                                          ├────────────────────┤
                                                          │ 🚪 Sign Out        │
                                                          └────────────────────┘
```

---

## Charts Section

### Token Usage Line Chart

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Token Usage Over Time                                  Last 30 days ▼     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  40M │                                                          ╭──        │
│      │                                              ╭───────────╯          │
│  30M │                              ╭───────────────╯                       │
│      │              ╭───────────────╯                                       │
│  20M │  ╭───────────╯                                                       │
│      │──╯                                                                   │
│  10M │                                                                      │
│      │                                                                      │
│   0  └──────────────────────────────────────────────────────────────────    │
│        Dec 1    Dec 8     Dec 15    Dec 22    Dec 29                       │
│                                                                             │
│  Legend:  ● Engineering  ● Product  ● Sales  ● Marketing                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Team Usage Bar Chart

```
┌─────────────────────────────────────────┐
│  TOP TEAMS BY USAGE                     │
├─────────────────────────────────────────┤
│                                         │
│  Engineering  ████████████████████ 523M │
│  Product      ███████░░░░░░░░░░░░ 187M  │
│  Sales        ████░░░░░░░░░░░░░░░  94M  │
│  Marketing    ██░░░░░░░░░░░░░░░░░  43M  │
│                                         │
│  View all teams →                       │
└─────────────────────────────────────────┘
```

---

## Component Specifications

### Sidebar

| Property | Value |
|----------|-------|
| Width | 240px (collapsed: 64px) |
| Background | #F9FAFB |
| Border Right | 1px solid #E5E7EB |
| Nav Item Height | 40px |
| Active Item BG | #EFF6FF |
| Active Text | #2563EB |
| Hover BG | #F3F4F6 |

### Metric Card

| Property | Value |
|----------|-------|
| Height | 120px |
| Border Radius | 12px |
| Background | White |
| Border | 1px solid #E5E7EB |
| Shadow | 0 1px 3px rgba(0,0,0,0.1) |
| Padding | 20px |
| Title Font | Inter 12px Medium, #6B7280 |
| Value Font | Inter 32px Bold, #111827 |
| Trend Font | Inter 14px Regular |
| Trend Up | #10B981 (green) |
| Trend Down | #EF4444 (red) |

### Top Navigation

| Property | Value |
|----------|-------|
| Height | 64px |
| Background | White |
| Border Bottom | 1px solid #E5E7EB |
| Logo Size | 32px |
| Nav Link Font | Inter 14px Medium |
| Nav Active | Blue underline, 2px |
| Icon Size | 20px |

---

## Responsive Behavior

### Desktop (1280px+)
- Full sidebar visible
- 3 cards per row
- Full chart width

### Tablet (768-1279px)
- Collapsed sidebar (icons only)
- 2 cards per row
- Stacked sections

### Mobile (< 768px)
```
┌─────────────────────────┐
│ ☰ MINDWEAVE      🔔 👤 │
├─────────────────────────┤
│                         │
│  TOTAL TOKENS           │
│  847.2M   ↑ 23%        │
│                         │
├─────────────────────────┤
│  TOTAL COST             │
│  $42,350  ↑ 18%        │
│                         │
├─────────────────────────┤
│                         │
│  [Chart - scrollable]   │
│                         │
├─────────────────────────┤
│  TOP TEAMS              │
│  1. Engineering  523M   │
│  2. Product      187M   │
│                         │
└─────────────────────────┘
```

---

## Empty States

### New User (No Data)

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│                    Welcome to MindWeave! 🎉                     │
│                                                                 │
│         ┌─────────────────────────────────────────┐            │
│         │                                         │            │
│         │    No Claude usage data yet.           │            │
│         │                                         │            │
│         │    Connect your Claude API to start    │            │
│         │    tracking usage across your team.     │            │
│         │                                         │            │
│         │    ┌─────────────────────────┐         │            │
│         │    │  Connect Claude API     │         │            │
│         │    └─────────────────────────┘         │            │
│         │                                         │            │
│         │    Or, explore with sample data →      │            │
│         │                                         │            │
│         └─────────────────────────────────────────┘            │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Related Documents

- [WIREFRAME-TOKEN-USAGE.md](./WIREFRAME-TOKEN-USAGE.md) - Detailed token view
- [DESIGN-SYSTEM.md](../design/DESIGN-SYSTEM.md) - Design tokens
- [DATA-VISUALIZATION.md](../design/DATA-VISUALIZATION.md) - Chart specs

---

*Last Updated: December 2025*
*Owner: Product Design*
