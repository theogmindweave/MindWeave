# Wireframe: Hivemind Discovery Engine

> Complete wireframe specifications for the Hivemind AI-Powered Duplicate Detection experience

---

## Overview

| Field | Value |
|-------|-------|
| **Screen** | Hivemind Discovery Engine |
| **Priority** | P1 (v1.0) |
| **User Entry** | Navigation, Dashboard Alert |
| **Exit Points** | MCP Detail, Merge Wizard |

---

## Screen 1: Hivemind Dashboard

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│  ┌────┐                                                                                     │
│  │ ◇  │ MindWeave                             🔍 Search...                  👤 Susan Chen ▼ │
│  └────┘                                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│ ┌─────────────┐                                                                             │
│ │             │  ← Hivemind Discovery Engine                                Settings ⚙     │
│ │  Dashboard  │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │  📊 Usage   │  │  🧠 Hivemind Analysis Summary                                       │   │
│ │             │  │                                                                      │   │
│ │  👥 Teams   │  │  ┌──────────────────┐ ┌──────────────────┐ ┌──────────────────┐     │   │
│ │             │  │  │  Potential       │ │   Merge          │ │   Savings        │     │   │
│ │  🔷 MCPs    │  │  │  Duplicates      │ │   Candidates     │ │   Estimate       │     │   │
│ │             │  │  │                  │ │                  │ │                  │     │   │
│ │  📋 Audit   │  │  │     23           │ │     12           │ │   $47,000        │     │   │
│ │             │  │  │                  │ │                  │ │   /year          │     │   │
│ │  🧠 Hivemind│  │  └──────────────────┘ └──────────────────┘ └──────────────────┘     │   │
│ │  ─────────  │  │                                                                      │   │
│ │  Duplicates │  │  Last scan: 2 hours ago                        [Run Full Scan Now]  │   │
│ │  Consolid.  │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │  ─────────  │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │  ⚙ Settings │  │  High-Confidence Duplicates                               View All → │   │
│ │             │  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  🔴 HIGH CONFIDENCE (95%)                                      │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  ┌────────────────────┐     ┌────────────────────┐            │ │   │
│ │             │  │  │  │ Salesforce Reader  │ ≈≈≈ │ SF CRM Connector   │            │ │   │
│ │             │  │  │  │ Backend Team       │     │ Sales Ops Team     │            │ │   │
│ │             │  │  │  │ 34 users           │     │ 28 users           │            │ │   │
│ │             │  │  │  └────────────────────┘     └────────────────────┘            │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  WHY SIMILAR:                                                  │ │   │
│ │             │  │  │  • Same Salesforce API endpoints                               │ │   │
│ │             │  │  │  • Identical authentication pattern                            │ │   │
│ │             │  │  │  • 89% capability overlap                                      │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  [View Details]  [Merge MCPs]  [Not a Duplicate]               │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  🟡 MEDIUM CONFIDENCE (78%)                                    │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  ┌────────────────────┐     ┌────────────────────┐            │ │   │
│ │             │  │  │  │ Jira Ticket Creator│ ≈≈≈ │ Jira Issue Manager │            │ │   │
│ │             │  │  │  │ Frontend Team      │     │ Backend Team       │            │ │   │
│ │             │  │  │  └────────────────────┘     └────────────────────┘            │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  [View Details]  [Merge MCPs]  [Not a Duplicate]               │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ └─────────────┘                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 2: Duplicate Detail View

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│  ┌────┐                                                                                     │
│  │ ◇  │ MindWeave                             🔍 Search...                  👤 Susan Chen ▼ │
│  └────┘                                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│ ┌─────────────┐                                                                             │
│ │             │  ← Back to Hivemind                                                         │
│ │  Dashboard  │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │  📊 Usage   │  │  Duplicate Analysis: Salesforce Reader ≈ SF CRM Connector          │   │
│ │             │  │                                                                      │   │
│ │  👥 Teams   │  │  Confidence: ████████████████████████░░░░ 95%                       │   │
│ │             │  │                                                                      │   │
│ │  🔷 MCPs    │  └─────────────────────────────────────────────────────────────────────┘   │
│ │             │                                                                             │
│ │  📋 Audit   │  ┌────────────────────────────────┐ ┌────────────────────────────────────┐ │
│ │             │  │  Salesforce Reader             │ │  SF CRM Connector                  │ │
│ │  🧠 Hivemind│  │                                │ │                                    │ │
│ │             │  │  Owner: Backend Team           │ │  Owner: Sales Ops Team             │ │
│ │  ─────────  │  │  Created: Oct 15, 2024         │ │  Created: Nov 3, 2024              │ │
│ │             │  │  Users: 34                     │ │  Users: 28                         │ │
│ │  ⚙ Settings │  │  Invocations: 12,450/mo        │ │  Invocations: 8,920/mo             │ │
│ │             │  │                                │ │                                    │ │
│ │             │  │  CAPABILITIES:                 │ │  CAPABILITIES:                     │ │
│ │             │  │  ✅ Query accounts             │ │  ✅ Query accounts                 │ │
│ │             │  │  ✅ Query contacts             │ │  ✅ Query contacts                 │ │
│ │             │  │  ✅ Query opportunities        │ │  ✅ Query opportunities            │ │
│ │             │  │  ✅ Search records             │ │  ✅ Search records                 │ │
│ │             │  │  ❌ Create records             │ │  ✅ Create records                 │ │
│ │             │  │  ❌ Update records             │ │  ✅ Update records                 │ │
│ │             │  │                                │ │                                    │ │
│ │             │  └────────────────────────────────┘ └────────────────────────────────────┘ │
│ │             │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  Similarity Analysis                                                │   │
│ │             │  │                                                                      │   │
│ │             │  │  DIMENSION               SIMILARITY    EVIDENCE                      │   │
│ │             │  │  ────────────────────────────────────────────────────────────────── │   │
│ │             │  │  Name                    72%           Similar naming pattern        │   │
│ │             │  │  Description             88%           Both mention CRM queries      │   │
│ │             │  │  Capabilities            89%           4/6 identical                 │   │
│ │             │  │  API Endpoints           95%           Same Salesforce URLs          │   │
│ │             │  │  Authentication          100%          Same OAuth pattern            │   │
│ │             │  │  ────────────────────────────────────────────────────────────────── │   │
│ │             │  │  OVERALL                 95%                                         │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │             │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  🧠 Hivemind Recommendation                                         │   │
│ │             │  │                                                                      │   │
│ │             │  │  MERGE these MCPs into a single canonical "Salesforce MCP":         │   │
│ │             │  │                                                                      │   │
│ │             │  │  • Combine capabilities from both                                    │   │
│ │             │  │  • Use Backend Team's implementation (more mature)                  │   │
│ │             │  │  • Add write capabilities from Sales Ops version                     │   │
│ │             │  │  • Migrate 28 users from SF CRM Connector                           │   │
│ │             │  │                                                                      │   │
│ │             │  │  IMPACT:  Save $8,500/year  •  Reduce security surface              │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │             │                                                                             │
│ │             │  [Start Merge Wizard]  [Mark as Not Duplicate]  [Remind Me Later]          │
│ │             │                                                                             │
│ └─────────────┘                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 3: Consolidation Opportunities

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│  ┌────┐                                                                                     │
│  │ ◇  │ MindWeave                             🔍 Search...                  👤 Susan Chen ▼ │
│  └────┘                                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│ ┌─────────────┐                                                                             │
│ │             │  ← Hivemind / Consolidation Opportunities                                   │
│ │  Dashboard  │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │  📊 Usage   │  │  Consolidation Opportunities                                        │   │
│ │             │  │                                                                      │   │
│ │  👥 Teams   │  │  Hivemind identified groups of MCPs that could be consolidated     │   │
│ │             │  │  into single, canonical integrations.                               │   │
│ │  🔷 MCPs    │  │                                                                      │   │
│ │             │  │  Total Potential Savings: $47,000/year                              │   │
│ │  📋 Audit   │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │  🧠 Hivemind│                                                                             │
│ │  ─────────  │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │  Duplicates │  │                                                                      │   │
│ │  Consolid.  │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  📦 Salesforce MCPs (5 MCPs → 1 recommended)                   │ │   │
│ │  ─────────  │  │  │                                                                │ │   │
│ │             │  │  │  Salesforce Reader ─────┐                                      │ │   │
│ │  ⚙ Settings │  │  │  SF CRM Connector ──────┤                                      │ │   │
│ │             │  │  │  Salesforce Query ──────┼───► Unified Salesforce MCP          │ │   │
│ │             │  │  │  SF Account Lookup ─────┤                                      │ │   │
│ │             │  │  │  SFDC Data Fetcher ─────┘                                      │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Estimated Savings: $18,000/year                               │ │   │
│ │             │  │  │  Engineering Time: 120 hours saved                             │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  [View Consolidation Plan]  [Start Merge Wizard]               │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  📦 Jira MCPs (3 MCPs → 1 recommended)                         │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Jira Ticket Creator ───┐                                      │ │   │
│ │             │  │  │  Jira Issue Manager ────┼───► Unified Jira MCP                │ │   │
│ │             │  │  │  Jira Project Reader ───┘                                      │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Estimated Savings: $12,000/year                               │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  [View Consolidation Plan]  [Start Merge Wizard]               │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  📦 Slack MCPs (4 MCPs → 2 recommended)                        │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Estimated Savings: $9,500/year                                │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  [View Consolidation Plan]  [Start Merge Wizard]               │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ └─────────────┘                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 4: Pre-Registration Duplicate Check

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│  ┌────┐                                                                                     │
│  │ ◇  │ MindWeave                             🔍 Search...                  👤 Susan Chen ▼ │
│  └────┘                                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                             │
│  ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│  │  Register New MCP - Step 2 of 4                                                     │   │
│  │                                                                                      │   │
│  │  ● Basic Info  ○ Capabilities  ○ Access  ○ Review                                  │   │
│  │                                                                                      │   │
│  │  ─────────────────────────────────────────────────────────────────────────────────  │   │
│  │                                                                                      │   │
│  │  ┌────────────────────────────────────────────────────────────────────────────────┐│   │
│  │  │  ⚠️ Hivemind Alert: Similar MCPs Found                                        ││   │
│  │  │                                                                                ││   │
│  │  │  Before registering "Slack Message Sender", consider these                     ││   │
│  │  │  existing MCPs that may already meet your needs:                               ││   │
│  │  │                                                                                ││   │
│  │  │  ┌──────────────────────────────────────────────────────────────────────────┐││   │
│  │  │  │  🔷 Slack Poster (91% similar)                                           │││   │
│  │  │  │     Owner: Platform Team                                                 │││   │
│  │  │  │     Users: 45 across 8 teams                                             │││   │
│  │  │  │     Status: ✅ Approved                                                  │││   │
│  │  │  │                                                                          │││   │
│  │  │  │     Capabilities: Post messages, Send DMs, Upload files                  │││   │
│  │  │  │                                                                          │││   │
│  │  │  │     [View Details]  [Request Access]                                     │││   │
│  │  │  │                                                                          │││   │
│  │  │  └──────────────────────────────────────────────────────────────────────────┘││   │
│  │  │                                                                                ││   │
│  │  │  ┌──────────────────────────────────────────────────────────────────────────┐││   │
│  │  │  │  🔷 Slack Notification MCP (78% similar)                                 │││   │
│  │  │  │     Owner: IT Team                                                       │││   │
│  │  │  │     Users: 22 across 3 teams                                             │││   │
│  │  │  │     Status: ✅ Approved                                                  │││   │
│  │  │  │                                                                          │││   │
│  │  │  │     [View Details]  [Request Access]                                     │││   │
│  │  │  │                                                                          │││   │
│  │  │  └──────────────────────────────────────────────────────────────────────────┘││   │
│  │  │                                                                                ││   │
│  │  │  ─────────────────────────────────────────────────────────────────────────── ││   │
│  │  │                                                                                ││   │
│  │  │  Why create a new MCP when similar ones exist?                                ││   │
│  │  │  ┌──────────────────────────────────────────────────────────────────────────┐││   │
│  │  │  │                                                                          │││   │
│  │  │  │  Please explain why you need a new MCP...                                │││   │
│  │  │  │                                                                          │││   │
│  │  │  └──────────────────────────────────────────────────────────────────────────┘││   │
│  │  │                                                                                ││   │
│  │  │  [Use Existing MCP]  [Continue Registration Anyway]                           ││   │
│  │  │                                                                                ││   │
│  │  └────────────────────────────────────────────────────────────────────────────────┘│   │
│  │                                                                                      │   │
│  └─────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 5: Merge Wizard - Step 1

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│                                                                                             │
│           ┌─────────────────────────────────────────────────────────────────────┐          │
│           │  Merge MCPs                                                  [X]    │          │
│           ├─────────────────────────────────────────────────────────────────────┤          │
│           │                                                                      │          │
│           │  Step 1 of 3: Select Primary MCP                                     │          │
│           │                                                                      │          │
│           │  ● Primary  ○ Capabilities  ○ Confirm                               │          │
│           │                                                                      │          │
│           │  ─────────────────────────────────────────────────────────────      │          │
│           │                                                                      │          │
│           │  Choose which MCP will become the canonical version:                 │          │
│           │                                                                      │          │
│           │  ┌─────────────────────────────────────────────────────────────┐    │          │
│           │  │  ● Salesforce Reader (Recommended)                          │    │          │
│           │  │                                                              │    │          │
│           │  │    Owner: Backend Team                                       │    │          │
│           │  │    Created: Oct 15, 2024 (older, more mature)               │    │          │
│           │  │    Users: 34                                                 │    │          │
│           │  │    Invocations: 12,450/mo                                    │    │          │
│           │  │                                                              │    │          │
│           │  └─────────────────────────────────────────────────────────────┘    │          │
│           │                                                                      │          │
│           │  ┌─────────────────────────────────────────────────────────────┐    │          │
│           │  │  ○ SF CRM Connector                                         │    │          │
│           │  │                                                              │    │          │
│           │  │    Owner: Sales Ops Team                                     │    │          │
│           │  │    Created: Nov 3, 2024 (newer)                             │    │          │
│           │  │    Users: 28                                                 │    │          │
│           │  │    Invocations: 8,920/mo                                     │    │          │
│           │  │                                                              │    │          │
│           │  └─────────────────────────────────────────────────────────────┘    │          │
│           │                                                                      │          │
│           │  ─────────────────────────────────────────────────────────────      │          │
│           │                                                                      │          │
│           │  The selected MCP will:                                              │          │
│           │  • Become the single canonical version                               │          │
│           │  • Inherit capabilities from the merged MCP                          │          │
│           │  • Receive all users from the deprecated MCP                         │          │
│           │                                                                      │          │
│           │  ┌────────────────────┐  ┌────────────────────┐                     │          │
│           │  │      Cancel        │  │   Next →           │                     │          │
│           │  └────────────────────┘  └────────────────────┘                     │          │
│           │                                                                      │          │
│           └─────────────────────────────────────────────────────────────────────┘          │
│                                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Component Specifications

### Confidence Badge

| Confidence | Color | Label |
|------------|-------|-------|
| 90-100% | Red | HIGH |
| 70-89% | Yellow | MEDIUM |
| 50-69% | Gray | LOW |

### MCP Comparison Card

| Property | Value |
|----------|-------|
| Layout | Side-by-side |
| Width | 50% each |
| Capability Match | Green check / red X |

### Similarity Bar

| Property | Value |
|----------|-------|
| Height | 8px |
| Border Radius | 4px |
| Fill Color | Blue gradient |
| Background | Gray |

### Consolidation Arrow

| Property | Value |
|----------|-------|
| Style | Dashed line with arrow |
| Color | Blue |
| Animation | Subtle pulse |

---

## Related Documents

- [FEATURE-HIVEMIND.md](../features/FEATURE-HIVEMIND.md) - Feature spec
- [WIREFRAME-MCP-REGISTRY.md](./WIREFRAME-MCP-REGISTRY.md) - MCP Registry

---

*Last Updated: December 2025*
*Owner: Design Lead*
