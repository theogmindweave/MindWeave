# Wireframe: Login & Authentication

> SSO-first authentication flow for enterprise users

---

## Screen Overview

| Attribute | Value |
|-----------|-------|
| Screen ID | AUTH-001 |
| Priority | P0 (MVP) |
| User Flow | Entry point |
| Mobile Support | Responsive |

---

## Main Login Screen

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                           ░░░░░░░░░░░░░░░░░░░░░                            │
│                           ░   MINDWEAVE LOGO   ░                            │
│                           ░░░░░░░░░░░░░░░░░░░░░                            │
│                                                                             │
│                    Enterprise AI Governance Platform                        │
│                                                                             │
│           ┌─────────────────────────────────────────────────┐              │
│           │                                                 │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │  🏢  Sign in with Okta              │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │  🔷  Sign in with Azure AD          │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │  🔶  Sign in with Google Workspace  │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     ─────────────── or ───────────────          │              │
│           │                                                 │              │
│           │     Email                                       │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │ you@company.com                     │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     Password                                    │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │ ••••••••••••••••              👁️   │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     ☐ Remember me on this device                │              │
│           │                                                 │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │           Sign In                   │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     Forgot password?    Need help?              │              │
│           │                                                 │              │
│           └─────────────────────────────────────────────────┘              │
│                                                                             │
│                    © 2025 The Mind Weave. All rights reserved.             │
│                         Privacy Policy | Terms of Service                   │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## SSO Provider Selection (Enterprise)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                           ░░░░░░░░░░░░░░░░░░░░░                            │
│                           ░   MINDWEAVE LOGO   ░                            │
│                           ░░░░░░░░░░░░░░░░░░░░░                            │
│                                                                             │
│                         Sign in to your organization                        │
│                                                                             │
│           ┌─────────────────────────────────────────────────┐              │
│           │                                                 │              │
│           │     Enter your work email                       │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │ you@acmecorp.com                    │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │           Continue                  │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     ─────────────────────────────────────       │              │
│           │                                                 │              │
│           │     ℹ️  Your organization uses Okta for         │              │
│           │        authentication. You'll be redirected     │              │
│           │        to sign in securely.                     │              │
│           │                                                 │              │
│           └─────────────────────────────────────────────────┘              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## MFA Verification Screen

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│                           ░░░░░░░░░░░░░░░░░░░░░                            │
│                           ░   MINDWEAVE LOGO   ░                            │
│                           ░░░░░░░░░░░░░░░░░░░░░                            │
│                                                                             │
│                        Two-Factor Authentication                            │
│                                                                             │
│           ┌─────────────────────────────────────────────────┐              │
│           │                                                 │              │
│           │     Enter the code from your authenticator app  │              │
│           │                                                 │              │
│           │         ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐ ┌───┐    │              │
│           │         │ 4 │ │ 7 │ │ 2 │ │ 9 │ │ _ │ │ _ │    │              │
│           │         └───┘ └───┘ └───┘ └───┘ └───┘ └───┘    │              │
│           │                                                 │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │           Verify                    │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     Can't access your authenticator?            │              │
│           │     Use backup code instead                     │              │
│           │                                                 │              │
│           └─────────────────────────────────────────────────┘              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## First-Time User Onboarding

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                                                                             │
│  Step 1 of 3                                               ●───●───○       │
│                                                                             │
│                        Welcome to MindWeave! 🎉                             │
│                                                                             │
│           ┌─────────────────────────────────────────────────┐              │
│           │                                                 │              │
│           │     Let's set up your profile                   │              │
│           │                                                 │              │
│           │     Full Name                                   │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │ Susan Chen                          │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     Job Title                                   │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │ Engineering Manager            ▼    │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │     Team                                        │              │
│           │     ┌─────────────────────────────────────┐     │              │
│           │     │ Backend Engineering            ▼    │     │              │
│           │     └─────────────────────────────────────┘     │              │
│           │                                                 │              │
│           │                              ┌────────────┐     │              │
│           │                              │   Next →   │     │              │
│           │                              └────────────┘     │              │
│           │                                                 │              │
│           └─────────────────────────────────────────────────┘              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Component Specifications

### SSO Button

| Property | Value |
|----------|-------|
| Height | 48px |
| Width | 100% (max 360px) |
| Border Radius | 8px |
| Background | White |
| Border | 1px solid #E5E7EB |
| Hover | Background #F9FAFB |
| Icon Size | 24px |
| Font | Inter 16px Medium |
| Gap (icon-text) | 12px |

### Primary Button (Sign In)

| Property | Value |
|----------|-------|
| Height | 48px |
| Width | 100% |
| Border Radius | 8px |
| Background | #2563EB (Primary Blue) |
| Hover | #1D4ED8 |
| Font | Inter 16px Semibold |
| Color | White |

### Input Field

| Property | Value |
|----------|-------|
| Height | 48px |
| Border Radius | 8px |
| Border | 1px solid #D1D5DB |
| Focus Border | 2px solid #2563EB |
| Padding | 12px 16px |
| Font | Inter 16px Regular |
| Label | Inter 14px Medium, #374151 |

### Password Toggle

| Property | Value |
|----------|-------|
| Icon | Eye / EyeOff |
| Size | 20px |
| Color | #6B7280 |
| Position | Right, 16px from edge |

---

## States

### Loading State

```
┌─────────────────────────────────────────────────┐
│                                                 │
│     ┌─────────────────────────────────────┐     │
│     │    ◠ Signing you in...              │     │
│     └─────────────────────────────────────┘     │
│                                                 │
└─────────────────────────────────────────────────┘
```

### Error State

```
┌─────────────────────────────────────────────────┐
│                                                 │
│     ⚠️ Invalid email or password               │
│        Please try again.                        │
│                                                 │
│     Email                                       │
│     ┌─────────────────────────────────────┐     │
│     │ you@company.com              ❌     │     │
│     └─────────────────────────────────────┘     │
│     (Border: #EF4444)                           │
│                                                 │
└─────────────────────────────────────────────────┘
```

### SSO Error State

```
┌─────────────────────────────────────────────────┐
│                                                 │
│     ⚠️ Organization not configured             │
│        Contact your IT administrator            │
│        to enable MindWeave access.              │
│                                                 │
│     Need help? Contact support@mindweave.ai     │
│                                                 │
└─────────────────────────────────────────────────┘
```

---

## User Flows

### Flow 1: SSO Login (Happy Path)

```
┌─────────┐    ┌─────────────┐    ┌─────────────┐    ┌───────────┐
│  Login  │───▶│ Enter Email │───▶│ Okta/Azure  │───▶│ Dashboard │
│  Screen │    │   (detect   │    │   Login     │    │  (home)   │
│         │    │    org)     │    │             │    │           │
└─────────┘    └─────────────┘    └─────────────┘    └───────────┘
```

### Flow 2: Email/Password Login

```
┌─────────┐    ┌─────────────┐    ┌───────────┐    ┌───────────┐
│  Login  │───▶│   Enter     │───▶│    MFA    │───▶│ Dashboard │
│  Screen │    │ Credentials │    │  (if on)  │    │           │
└─────────┘    └─────────────┘    └───────────┘    └───────────┘
```

### Flow 3: First-Time User

```
┌─────────┐    ┌──────────┐    ┌─────────────┐    ┌───────────┐
│   SSO   │───▶│ Profile  │───▶│   Select    │───▶│ Dashboard │
│  Login  │    │  Setup   │    │    Team     │    │  (tour)   │
└─────────┘    └──────────┘    └─────────────┘    └───────────┘
```

---

## Accessibility Requirements

| Requirement | Implementation |
|-------------|----------------|
| Keyboard navigation | Tab order: SSO buttons → Email → Password → Submit |
| Screen reader | Labels on all inputs, button descriptions |
| Color contrast | WCAG AA (4.5:1 minimum) |
| Focus indicators | 2px blue outline on focus |
| Error announcements | ARIA live regions for errors |

---

## Responsive Breakpoints

| Breakpoint | Layout |
|------------|--------|
| Desktop (1024px+) | Centered card, 480px max width |
| Tablet (768-1023px) | Centered card, 90% width |
| Mobile (< 768px) | Full width, 16px horizontal padding |

---

## Related Documents

- [FEATURE-SSO-AUTH.md](../features/FEATURE-SSO-AUTH.md) - SSO feature spec
- [DESIGN-SYSTEM.md](../design/DESIGN-SYSTEM.md) - Design tokens
- [AUTHENTICATION-FLOW.md](../../05-engineering/AUTHENTICATION-FLOW.md) - Technical flow

---

*Last Updated: December 2025*
*Owner: Product Design*
