# Wireframe: MCP Detail View

> Complete wireframe specifications for the MCP Detail experience

---

## Overview

| Field | Value |
|-------|-------|
| **Screen** | MCP Detail |
| **Priority** | P0 (MVP) |
| **User Entry** | MCP Registry, Search, Dashboard |
| **Exit Points** | Back to Registry, Related MCPs |

---

## Screen 1: MCP Detail - Overview Tab

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│  ┌────┐                                                                                     │
│  │ ◇  │ MindWeave                             🔍 Search...                  👤 Susan Chen ▼ │
│  └────┘                                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│ ┌─────────────┐                                                                             │
│ │             │  ← Back to Registry                                                         │
│ │  Dashboard  │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │  📊 Usage   │  │                                                                      │   │
│ │             │  │  🔷 Salesforce CRM Reader                                           │   │
│ │  👥 Teams   │  │                                                                      │   │
│ │             │  │  Status: ✅ Approved     Category: CRM      Version: 2.1.0         │   │
│ │  🔷 MCPs    │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │  📋 Audit   │                                                                             │
│ │             │  [Overview]  [Capabilities]  [Usage]  [Access]  [History]                  │
│ │  🧠 Hivemind│  ═══════════                                                               │
│ │             │                                                                             │
│ │  ─────────  │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  DESCRIPTION                                                        │   │
│ │  ⚙ Settings │  │                                                                      │   │
│ │             │  │  Read and query Salesforce CRM objects including Accounts,          │   │
│ │             │  │  Contacts, Opportunities, and custom objects. Supports SOQL         │   │
│ │             │  │  queries and record lookups by ID.                                  │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │             │                                                                             │
│ │             │  ┌───────────────────────────────┐ ┌───────────────────────────────────┐   │
│ │             │  │  OWNERSHIP                    │ │  USAGE STATISTICS                 │   │
│ │             │  │                               │ │                                   │   │
│ │             │  │  Owner: Sales Operations      │ │  Teams Using: 34                  │   │
│ │             │  │  Team: Sales                  │ │  Unique Users: 127                │   │
│ │             │  │                               │ │  Monthly Invocations: 8,247       │   │
│ │             │  │  Created: Oct 15, 2024        │ │                                   │   │
│ │             │  │  Last Updated: Dec 10, 2024   │ │  Trend (30d):                     │   │
│ │             │  │  Security Review: Dec 1, 2024 │ │  ▁▂▃▄▅▆▇█▇▆▅▆▇█████▇▆▅▆▇███      │   │
│ │             │  │                               │ │                                   │   │
│ │             │  │  [Contact Owner]              │ │  [View Detailed Stats]            │   │
│ │             │  │                               │ │                                   │   │
│ │             │  └───────────────────────────────┘ └───────────────────────────────────┘   │
│ │             │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  DATA ACCESS                                                        │   │
│ │             │  │                                                                      │   │
│ │             │  │  ⚠️ This MCP accesses the following data types:                     │   │
│ │             │  │                                                                      │   │
│ │             │  │  • Customer Data: Accounts, Contacts, Opportunities                 │   │
│ │             │  │  • PII: Contact email, phone, address                               │   │
│ │             │  │  • Business Data: Deal values, revenue                              │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │             │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │                                                                      │   │
│ │             │  │  [Request Access]  [Report Issue]  [Share]                          │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ └─────────────┘                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 2: MCP Detail - Capabilities Tab

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│  ┌────┐                                                                                     │
│  │ ◇  │ MindWeave                             🔍 Search...                  👤 Susan Chen ▼ │
│  └────┘                                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│ ┌─────────────┐                                                                             │
│ │             │  ← Back to Registry                                                         │
│ │  Dashboard  │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │  📊 Usage   │  │  🔷 Salesforce CRM Reader                                           │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │  👥 Teams   │                                                                             │
│ │             │  [Overview]  [Capabilities]  [Usage]  [Access]  [History]                  │
│ │  🔷 MCPs    │               ═══════════════                                              │
│ │             │                                                                             │
│ │  📋 Audit   │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  CAPABILITIES (4)                                                   │   │
│ │  🧠 Hivemind│  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │  ─────────  │  │  │  query_objects                                                 │ │   │
│ │             │  │  │                                                                │ │   │
│ │  ⚙ Settings │  │  │  Execute SOQL queries against Salesforce objects              │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Parameters:                                                   │ │   │
│ │             │  │  │  • query (string): SOQL query string                           │ │   │
│ │             │  │  │  • limit (number): Maximum records to return                   │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Returns: Array of Salesforce records                          │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  get_record                                                    │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Retrieve a specific record by ID                              │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Parameters:                                                   │ │   │
│ │             │  │  │  • object_type (string): Account, Contact, Opportunity         │ │   │
│ │             │  │  │  • record_id (string): Salesforce record ID                    │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Returns: Single Salesforce record                             │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  search_records                                                │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  Search across multiple object types                           │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  list_recent                                                   │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  List recently modified records                                │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ └─────────────┘                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 3: MCP Detail - Usage Tab

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│  ┌────┐                                                                                     │
│  │ ◇  │ MindWeave                             🔍 Search...                  👤 Susan Chen ▼ │
│  └────┘                                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│ ┌─────────────┐                                                                             │
│ │             │  ← Back to Registry                                                         │
│ │  Dashboard  │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │  📊 Usage   │  │  🔷 Salesforce CRM Reader                                           │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │  👥 Teams   │                                                                             │
│ │             │  [Overview]  [Capabilities]  [Usage]  [Access]  [History]                  │
│ │  🔷 MCPs    │                              ═══════                                        │
│ │             │                                                                             │
│ │  📋 Audit   │  ┌───────────────────┐ ┌───────────────────┐ ┌───────────────────┐         │
│ │             │  │  Teams Using      │ │  Unique Users     │ │  Invocations/Mo   │         │
│ │  🧠 Hivemind│  │                   │ │                   │ │                   │         │
│ │             │  │  34               │ │  127              │ │  8,247            │         │
│ │  ─────────  │  │                   │ │                   │ │                   │         │
│ │             │  │  ↑ 12% vs Nov     │ │  ↑ 8% vs Nov      │ │  ↑ 23% vs Nov     │         │
│ │  ⚙ Settings │  │                   │ │                   │ │                   │         │
│ │             │  └───────────────────┘ └───────────────────┘ └───────────────────┘         │
│ │             │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  Invocations Over Time                                              │   │
│ │             │  │                                                                      │   │
│ │             │  │        ▲                                                            │   │
│ │             │  │   400  │                                    ┌──┐    ┌──┐            │   │
│ │             │  │        │          ┌──┐         ┌──┐ ┌──┐    │  │    │  │            │   │
│ │             │  │   300  │     ┌──┐ │  │    ┌──┐ │  │ │  │    │  │    │  │ ┌──┐       │   │
│ │             │  │        │ ┌──┐│  │ │  │┌──┐│  │ │  │ │  │┌──┐│  │┌──┐│  │ │  │       │   │
│ │             │  │   200  │ │  ││  │ │  ││  ││  │ │  │ │  ││  ││  ││  ││  │ │  │       │   │
│ │             │  │        │ │  ││  │ │  ││  ││  │ │  │ │  ││  ││  ││  ││  │ │  │       │   │
│ │             │  │   100  └─────────────────────────────────────────────────────────   │   │
│ │             │  │           1   5    10   15   20   25   28                           │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │             │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  Top Teams Using This MCP                                           │   │
│ │             │  │                                                                      │   │
│ │             │  │  1. Sales           2,341 invocations   28%                         │   │
│ │             │  │     ████████████████████████████                                    │   │
│ │             │  │                                                                      │   │
│ │             │  │  2. Marketing       1,876 invocations   23%                         │   │
│ │             │  │     ██████████████████████                                          │   │
│ │             │  │                                                                      │   │
│ │             │  │  3. Customer Succ   1,543 invocations   19%                         │   │
│ │             │  │     ██████████████████                                              │   │
│ │             │  │                                                                      │   │
│ │             │  │  [View All 34 Teams]                                                │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ └─────────────┘                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Screen 4: MCP Detail - Access Tab

```
┌─────────────────────────────────────────────────────────────────────────────────────────────┐
│  ┌────┐                                                                                     │
│  │ ◇  │ MindWeave                             🔍 Search...                  👤 Susan Chen ▼ │
│  └────┘                                                                                     │
├─────────────────────────────────────────────────────────────────────────────────────────────┤
│ ┌─────────────┐                                                                             │
│ │             │  ← Back to Registry                                                         │
│ │  Dashboard  │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │  📊 Usage   │  │  🔷 Salesforce CRM Reader                                           │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │  👥 Teams   │                                                                             │
│ │             │  [Overview]  [Capabilities]  [Usage]  [Access]  [History]                  │
│ │  🔷 MCPs    │                                       ════════                              │
│ │             │                                                                             │
│ │  📋 Audit   │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  ACCESS CONTROL                                                     │   │
│ │  🧠 Hivemind│  │                                                                      │   │
│ │             │  │  Visibility: Org-Wide                                               │   │
│ │  ─────────  │  │                                                                      │   │
│ │             │  │  All teams in the organization can discover and use this MCP.      │   │
│ │  ⚙ Settings │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │             │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  TEAMS WITH ACCESS (34)                             [+ Add Team]    │   │
│ │             │  │                                                                      │   │
│ │             │  │  🔍 Search teams...                                                  │   │
│ │             │  │                                                                      │   │
│ │             │  │  TEAM                    ACCESS LEVEL      GRANTED BY      DATE     │   │
│ │             │  │  ───────────────────────────────────────────────────────────────── │   │
│ │             │  │                                                                      │   │
│ │             │  │  ✓ Sales                 Full Access       Auto           Oct 15    │   │
│ │             │  │  ✓ Marketing             Full Access       John Smith     Oct 20    │   │
│ │             │  │  ✓ Customer Success      Full Access       John Smith     Nov 1     │   │
│ │             │  │  ✓ Engineering           Read Only         Sarah Lee      Nov 15    │   │
│ │             │  │  ✓ Product               Read Only         Sarah Lee      Dec 1     │   │
│ │             │  │                                                                      │   │
│ │             │  │  Showing 5 of 34 teams                           [View All]         │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ │             │                                                                             │
│ │             │  ┌─────────────────────────────────────────────────────────────────────┐   │
│ │             │  │  PENDING ACCESS REQUESTS (2)                                        │   │
│ │             │  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  Finance Team                                                  │ │   │
│ │             │  │  │  Requested by: Mike Wilson        Dec 26, 2025                │ │   │
│ │             │  │  │  Reason: Need access for revenue reporting                     │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  [Approve]  [Reject]  [Ask for More Info]                      │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  │  ┌────────────────────────────────────────────────────────────────┐ │   │
│ │             │  │  │  Legal Team                                                    │ │   │
│ │             │  │  │  Requested by: Emily Chen         Dec 27, 2025                │ │   │
│ │             │  │  │  Reason: Contract review automation                            │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  │  [Approve]  [Reject]  [Ask for More Info]                      │ │   │
│ │             │  │  │                                                                │ │   │
│ │             │  │  └────────────────────────────────────────────────────────────────┘ │   │
│ │             │  │                                                                      │   │
│ │             │  └─────────────────────────────────────────────────────────────────────┘   │
│ └─────────────┘                                                                             │
└─────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Component Specifications

### Tab Navigation

| Property | Value |
|----------|-------|
| Height | 48px |
| Active Indicator | 2px blue underline |
| Inactive Color | #6B7280 |
| Active Color | #2563EB |

### Capability Card

| Property | Value |
|----------|-------|
| Border | 1px solid #E5E7EB |
| Border Radius | 8px |
| Padding | 16px |
| Title Font | 14px Semibold |
| Description Font | 14px Regular |

### Access Request Card

| Property | Value |
|----------|-------|
| Border | 1px solid #FCD34D |
| Background | #FFFBEB |
| Border Radius | 8px |

---

## Related Documents

- [FEATURE-MCP-REGISTRY.md](../features/FEATURE-MCP-REGISTRY.md) - Feature spec
- [WIREFRAME-MCP-REGISTRY.md](./WIREFRAME-MCP-REGISTRY.md) - Registry list view

---

*Last Updated: December 2025*
*Owner: Design Lead*
